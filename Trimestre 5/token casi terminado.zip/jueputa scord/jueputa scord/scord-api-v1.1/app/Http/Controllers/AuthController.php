<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Tymon\JWTAuth\Facades\JWTAuth;
use Tymon\JWTAuth\Exceptions\JWTException;
use Illuminate\Support\Facades\Validator;

class AuthController extends Controller
{
    //login de usuario
     public function login(Request $request)
    {
       $validator = Validator::make($request->all(), [
          "correo"=> "required|email",
          "contraseña"=> "required|string|min:8",
       ]);

      if ($validator->fails()) {
          return response()->json(['error'=> $validator->errors()],422);
         }

       $credentials = $request->only('correo','contraseña');

       try{
          if(! $token = JWTAuth::attempt($credentials)) {
              return response()->json(['error'=> 'credenciales invalidas '],401);
          }
          return response()->json(['token'=> $token,'user'=> auth()->user()],200);

       }catch(JWTException $e){
          return response()->json(['error' => 'no se pudo crear el token'],500);
        } 
    }

    //obtener usuario autenticado
     
    public function me()
    {
      $user = auth()->user();
      return response()->json($user,200);
    }
    public function logout()
    {
      JWTAuth::invalidate(JWTAuth::getToken());
      return response()->json(['message'=> 'usuario desconectado existosamente'],200);
    }
     
}