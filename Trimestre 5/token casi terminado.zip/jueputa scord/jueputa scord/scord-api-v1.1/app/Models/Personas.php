<?php

namespace App\Models;


use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Model;


class Personas extends Model
{
    use HasFactory;
    protected $table = 'personas';

    protected $primaryKey = 'NumeroDeDocumento';
    public $incrementing = false;
    protected $keyType = 'int';

    public $timestamps = false;

    protected $fillable = [
        'NumeroDeDocumento',
        'Nombre1',
        'Nombre2',
        'Apellido1',
        'Apellido2',
        'FechaDeNacimiento',
        'Genero',
        'Telefono',
        'EpsSisben',
        'Direccion',
        'correo',
        'contraseña',
        'idTiposDeDocumentos',
        'idRoles',
    ];


    protected $hidden = [
        'contraseña',
        'remember_token',
    ];


    public function tipoDocumento(): BelongsTo
    {
        return $this->belongsTo(TipoDeDocumento::class, 'idTiposDeDocumentos');
    }

    public function rol(): BelongsTo
    {
        return $this->belongsTo(Roles::class, 'idRoles', 'idRoles');
    }

    public function getJWTIdentifier()
    {
        return $this->getKey();
    }

    public function getJWTCustomClaims()
    {
        return [];
    }


    public function getAuthPassword()
    {
        return $this->contraseña;
    }


    public function setContraseñaAttribute($value)
    {
        $this->attributes['contraseña'] = bcrypt($value);
    }


    public function getAuthIdentifierName()
    {
        return 'correo';
    }   

    
}
