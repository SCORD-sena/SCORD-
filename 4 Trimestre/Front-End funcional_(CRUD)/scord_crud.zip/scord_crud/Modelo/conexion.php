<?php
$conexion = new mysqli("localhost", "root", "", "scord");
$conexion->set_charset("utf8");
?>  